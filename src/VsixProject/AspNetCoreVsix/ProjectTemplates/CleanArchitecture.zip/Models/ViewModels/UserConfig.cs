
namespace $ext_safeprojectname$.Models.ViewModels
{
    public class UserConfig
    {
        
        public string AudienceType { get; set; }

        public string LanguageCode { get; set; }
    }
}
