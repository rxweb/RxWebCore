namespace $ext_safeprojectname$.Models.ViewModels
{
    public class StoreProcResult
    {
        public int Id { get; set; }

        public string Result { get; set; }
    }
}

