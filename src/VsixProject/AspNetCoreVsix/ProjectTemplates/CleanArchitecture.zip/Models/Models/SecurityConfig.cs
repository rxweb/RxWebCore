using System.Collections.Generic;

namespace $ext_safeprojectname$.Models
{
	public class SecurityConfig
    {
        public string[] AllowedHosts { get; set; }

		public string[] AllowedIps { get; set; }
    }
}

