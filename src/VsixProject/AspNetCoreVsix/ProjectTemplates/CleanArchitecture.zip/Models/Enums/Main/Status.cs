namespace $ext_safeprojectname$.Models.Enums.Main
{
    public enum Status
    {
        Active = 1,
        InActive = 3,
        Deleted = 4,
    }
}