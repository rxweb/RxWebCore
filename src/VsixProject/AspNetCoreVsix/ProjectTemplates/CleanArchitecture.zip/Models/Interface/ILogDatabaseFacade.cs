using RxWeb.Core.Annotations;

namespace $ext_safeprojectname$.BoundedContext.SqlContext
{
    public interface ILogDatabaseFacade :IDatabaseFacade
    {
    }
}